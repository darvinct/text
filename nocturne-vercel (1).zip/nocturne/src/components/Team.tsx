import { useState } from "react";
import { ArrowUpRight, MagnifyingGlass } from "@phosphor-icons/react";
import { copy, members, site, type Language } from "../data/site";
import { filterMembers } from "../lib/utils";
import { Modal } from "./Shell";

export function Team({ lang }: { lang: Language }) {
  const t = copy[lang];
  const [query, setQuery] = useState("");
  const [role, setRole] = useState("");
  const [sorted, setSorted] = useState(false);
  const [selected, setSelected] = useState<(typeof members)[number] | null>(
    null,
  );
  const result = filterMembers(members, query, role, sorted);
  return (
    <section className="section wrap" id="team">
      <div className="section-heading">
        <h2>{t.team}</h2>
        <p>{t.teamBody}</p>
        {site.isDemo && <span className="sample-label">{t.sampleTeam}</span>}
      </div>
      <div className="team-toolbar">
        <label className="search">
          <MagnifyingGlass size={20} />
          <span className="sr-only">{t.search}</span>
          <input
            type="search"
            placeholder={t.search}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </label>
        <label>
          <span className="sr-only">{t.all}</span>
          <select value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="">{t.all}</option>
            {[...new Set(members.map((m) => m.role))].map((r) => (
              <option key={r}>{r}</option>
            ))}
          </select>
        </label>
        <label>
          <span className="sr-only">{t.sort}</span>
          <select
            value={String(sorted)}
            onChange={(e) => setSorted(e.target.value === "true")}
          >
            <option value="false">{t.defaultSort}</option>
            <option value="true">{t.az}</option>
          </select>
        </label>
      </div>
      {result.length ? (
        <div className="team-grid">
          {result.map((member, i) => (
            <button
              className="member"
              key={member.id}
              onClick={() => setSelected(member)}
            >
              <span className={`avatar avatar-${i % 4}`}>
                {member.initials}
              </span>
              <span className="member-info">
                <strong>{member.name}</strong>
                <span>{member.role}</span>
                <small>{member.handle}</small>
              </span>
              <ArrowUpRight size={19} className="member-arrow" />
            </button>
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <MagnifyingGlass size={28} />
          <p>{t.noMembers}</p>
          <button
            className="button secondary"
            onClick={() => {
              setQuery("");
              setRole("");
            }}
          >
            {t.reset}
          </button>
        </div>
      )}
      {selected && (
        <Modal title={selected.name} onClose={() => setSelected(null)}>
          <span className="sample-label">
            {selected.role} · {selected.handle}
          </span>
          <p>
            {lang === "id"
              ? selected.bio
              : "Part of the example community team. Replace this profile with your own team details."}
          </p>
          {site.isDemo && <p className="muted">{t.sampleTeam}</p>}
        </Modal>
      )}
    </section>
  );
}
