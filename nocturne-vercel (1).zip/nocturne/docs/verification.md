# Hasil verifikasi

Dijalankan pada 26 Oktober 2026 di Node.js 24.19.0 dan Chromium headless. Pengujian berlaku untuk versi proyek ini; bukan sertifikasi keamanan, aksesibilitas penuh, atau jaminan performa jaringan pengguna.

- `npm run build`: TypeScript dan Vite production build lulus.
- `npm run check`: validasi undangan HTTPS/domain, pencarian/filter/urutan, ekspor batas karakter, dan penonaktifan mentions lulus.
- Browser smoke test pada build produksi: layout tanpa horizontal overflow pada 320, 390, 768, 1024, dan 1440 px.
- Pergantian bahasa dan persistensinya setelah reload, navigasi mobile, pencarian kosong, filter peran, urutan nama, filter event, modal, Escape, dan FAQ lulus.
- Form: save/restore/hapus draft, validasi browser, unduhan JSON, dan keterangan bahwa draft belum terkirim lulus.
- Twibbon: upload foto, zoom/posisi, reset, dan file PNG valid berukuran 1080×1080 lulus.
- Webhook: preview menampilkan teks berisi tag script sebagai teks, ekspor JSON valid, mentions kosong, dan tombol dinonaktifkan saat tidak ada konten lulus.
- Statistik: production build sementara dengan undangan contoh dan respons API tiruan menguji kegagalan, retry, serta angka berhasil dimuat. Build final mengosongkan undangan contoh itu kembali.
- Halaman tetap bisa dibuka dan memberi feedback saat browser memblokir localStorage.
- Route `/twibbon`, `/forms/public`, `/webhooks/editor`, dan halaman tidak ditemukan dibuka langsung pada preview lokal.
- Tidak ada uncaught JavaScript exception dalam pengujian tersebut.
- axe-core 4.10.3 pada `/`, `/twibbon`, `/forms/public`, `/webhooks/editor`, dengan tag `wcag2a`, `wcag2aa`, `wcag21aa`: 0 pelanggaran otomatis terdeteksi. Hasil otomatis tidak menggantikan uji screen reader/manual menyeluruh.

Belum diuji: publikasi ke akun Vercel milik pengguna, kondisi setiap perangkat/browser, integrasi server Discord milik pengguna, dan rendering preview sosial di domain final. Aturan rewrite/header Vercel disediakan dalam konfigurasi; penerapannya dapat diverifikasi setelah deploy.

## Screenshot

- `preview-hero.png`: tampilan awal desktop.
- `preview-desktop.png`: halaman komunitas lengkap desktop.
- `preview-mobile.png`: halaman komunitas lengkap ponsel.
- `preview-twibbon.png`: Twibbon Studio.
- `preview-public.png`: Form Komunitas.
- `preview-editor.png`: Webhook Studio.
