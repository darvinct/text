# Nocturne Community

Website komunitas Discord berbahasa Indonesia/Inggris, terinspirasi struktur publik ravenville.web.id. Dibuat dengan React, TypeScript, Vite, CSS, dan ikon Phosphor. Hosting Vercel sudah dikonfigurasi.

**Status:** siap dibangun dan di-deploy sebagai website statis. Identitas Nocturne, tim, dan kegiatan adalah contoh. Belum ada undangan Discord milikmu. Tidak menyertakan backend, OAuth Discord, dashboard admin, database, bot Discord, atau pengiriman webhook.

## Jalankan di komputer

Gunakan Node.js 22.18+ atau Node.js 24 LTS.

```sh
npm ci
npm run dev
```

Buka alamat yang ditampilkan terminal. Verifikasi produksi:

```sh
npm run build
npm run check
npm run preview
```

## Ubah menjadi milikmu

Edit `src/data/site.ts`:

```ts
export const site = {
  name: 'Nama Komunitasmu',
  tagline: 'Tagline komunitasmu.',
  discordInvite: 'https://discord.gg/kode-komunitasmu',
  instagram: 'https://instagram.com/username',
  contactEmail: 'email@domainmu.com',
  isDemo: true,
};
```

1. Ganti nama, undangan, serta kontak dengan data milikmu. Instagram dan email boleh kosong.
2. Ganti `members` dan `events` dengan tim serta kegiatan aslimu. Profil contoh tidak menggunakan akun orang lain. Setelah semua contoh diganti, set `isDemo: false`.
3. Teks Indonesia/Inggris tersedia pada objek `copy` di file yang sama. Deskripsi event memiliki kunci `id` dan `en`.
4. Ganti gambar di `public/images/` jika diperlukan, dan sesuaikan alt text event.
5. Ubah judul, deskripsi SEO, dan Open Graph di `index.html`. Untuk berbagi sosial setelah mendapat domain, gunakan URL absolut gambar: `https://domainmu.vercel.app/images/hero.webp`.
6. Jika ingin mengganti warna, edit token `:root` di `src/styles.css`. Semua font sudah lokal.

Undangan Discord yang valid mengaktifkan tombol gabung dan pengambilan perkiraan anggota/online dari endpoint undangan publik Discord. Bisa juga diatur lewat environment variable publik `VITE_DISCORD_INVITE` di Vercel, lalu redeploy. Tidak memerlukan bot token. Jika undangan kosong atau layanan Discord gagal, halaman tetap bisa dipakai dan menampilkan status yang jelas. Statistik voice, manusia, dan bot tidak dibuat-buat.

## Deploy ke Vercel lewat GitHub

1. Ekstrak ZIP, lalu buat repository GitHub berisi isi folder proyek ini. `package.json` harus berada di root repository.
2. Buka **Vercel → Add New → Project**, lalu import repository tersebut.
3. Pilih preset **Vite**. Build command: `npm run build`. Output directory: `dist`. Install command: `npm ci`.
4. Klik **Deploy**. Tidak perlu environment variable untuk fitur bawaan.
5. Uji URL `/twibbon`, `/forms/public`, dan `/webhooks/editor` dengan dibuka langsung dan di-refresh. `vercel.json` menangani route tersebut.

Alternatif lewat terminal, dari folder proyek:

```sh
npx vercel
npx vercel --prod
```

CLI akan meminta login ke akun Vercel milikmu. Proyek ini belum dipublikasikan ke akun apa pun.

## Fitur dan batasnya

| Bagian | Perilaku saat ini |
| --- | --- |
| Beranda | Responsif, navigasi mobile, bahasa ID/EN tersimpan lokal, FAQ |
| Server Stats | Perkiraan total anggota dan online dari undangan publik; loading, timeout, retry |
| Team | Pencarian nama/username/peran, filter peran, urut nama, modal profil |
| Portfolio | Filter kategori, detail kegiatan dalam modal |
| Twibbon | Upload JPG/PNG/WebP sampai 10 MB, crop persegi, zoom, posisi, teks nama, unduh PNG 1080×1080 |
| Form | Validasi native, simpan draft di perangkat, hapus draft, unduh JSON; opsional buka draft email |
| Webhook Studio | Preview embed, batas karakter Discord, pemilih warna, salin/unduh JSON; mentions dinonaktifkan |

Twibbon memproses foto di browser dan tidak mengunggahnya. Form tidak mengklaim berhasil mengirim: pengiriman ke pengurus harus dilakukan lewat kanal resmi atau aplikasi email. Membuka email tidak otomatis mengirimnya. Webhook Studio tidak meminta URL webhook atau token dan tidak mengirim pesan.

Untuk menyamai sistem terautentikasi pada referensi, tambahkan backend OAuth2 Discord, sesi aman, database, kontrol akses admin, serta endpoint server untuk formulir/webhook. Jangan menaruh client secret, bot token, atau URL webhook di kode frontend atau variabel `VITE_*`.

## Verifikasi

`npm run check` memeriksa validasi undangan (termasuk domain palsu), pencarian/filter/urutan tim, batas ekspor embed, dan pencegahan mentions. `npm run build` menjalankan TypeScript dan build produksi.

`scripts/smoke.py` menguji browser, tampilan 320/390/768/1024/1440 px, modal/keyboard, bahasa, pencarian, formulir, crop/unduh Twibbon, ekspor webhook, error/retry statistik dengan API tiruan, dan route langsung. Untuk menjalankannya:

```sh
python -m pip install playwright
python -m playwright install chromium
# Jalankan npm run dev di terminal lain.
python scripts/smoke.py
```

Screenshot dan hasil pengujian ada di `docs/verification.md`. Analisis referensi ada di `docs/analysis.md`. Sumber aset dan lisensi font ada di `docs/assets.md`.
